import 'package:college_project/models/user_models.dart';
import 'package:flutter/material.dart';

class UserInputScreen extends StatefulWidget {
  const UserInputScreen({super.key});

  @override
  State<UserInputScreen> createState() => _UserInputScreenState();
}

class _UserInputScreenState extends State<UserInputScreen> {
  final _formKey = GlobalKey<FormState>();

  final nameCtrl = TextEditingController();
  final ageCtrl = TextEditingController();
  final weightCtrl = TextEditingController();
  final heightCtrl = TextEditingController();

  String gender = "Male";
  String goal = "Muscle Gain";

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final newUser = User(
        name: nameCtrl.text,
        weight: weightCtrl.text,
        thisWeek: 0,
        completed: 0,
        todayWorkout: "Chest Day",
        exercisesCount: 5,
        exercises: [
          "Barbell Bench Press",
          "Incline Dumbbell Press",
          "Decline Bench Press",
          "Chest Fly Machine",
          "Push-Ups",
        ],
        weeklyProgress: {
          "Mon": 0, "Tue": 0, "Wed": 0, "Thu": 0, "Fri": 0, "Sat": 0, "Sun": 0,
        },
      );
      Navigator.pushNamed(context, '/dashboard', arguments: newUser);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 15),
            _buildForm(),
            const SizedBox(height: 15),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(22, 45, 22, 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade600, Colors.blue.shade900],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        image: const DecorationImage(
          image: NetworkImage("https://cdn-icons-png.flaticon.com/512/5957/5957239.png"),
          alignment: Alignment.centerRight,
          scale: 3,
          opacity: .12,
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Let’s Get Started 💪", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white)),
          SizedBox(height: 6),
          Text("We’ll build a workout plan based on your details", style: TextStyle(fontSize: 15, color: Colors.white70)),
        ],
      ),
    );
  }

  Widget _buildForm() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 10, offset: const Offset(0, 4))
          ],
        ),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildInput("Full Name", nameCtrl, Icons.person),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _buildInput("Age", ageCtrl, Icons.cake, type: TextInputType.number)),
                  const SizedBox(width: 8),
                  Expanded(child: _buildInput("Weight", weightCtrl, Icons.monitor_weight, type: TextInputType.number)),
                  const SizedBox(width: 8),
                  Expanded(child: _buildInput("Height", heightCtrl, Icons.height, type: TextInputType.number)),
                ],
              ),
              const SizedBox(height: 12),
              _buildSelectionRow("Gender", gender, ["Male", "Female", "Other"], (v) => setState(() => gender = v)),
              const SizedBox(height: 12),
              _buildSelectionRow("Goal", goal, ["Muscle Gain", "Fat Loss", "Stay Fit"], (v) => setState(() => goal = v)),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: _submit,
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: EdgeInsets.zero,
                  ),
                  child: Ink(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: LinearGradient(colors: [Colors.blue.shade600, Colors.blue.shade900]),
                    ),
                    child: const Center(
                      child: Text("Continue", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput(String label, TextEditingController ctrl, IconData icon, {TextInputType type = TextInputType.text}) {
    return TextFormField(
      controller: ctrl,
      keyboardType: type,
      validator: (v) => v!.isEmpty ? "Required field" : null,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: const Color(0xFFF3F5FA),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      ),
    );
  }

  Widget _buildSelectionRow(String label, String value, List<String> options, Function(String) onChange) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          children: options.map((e) {
            bool selected = value == e;
            return ChoiceChip(
              label: Text(e),
              selected: selected,
              onSelected: (_) => onChange(e),
              selectedColor: Colors.blue.shade700,
              labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
            );
          }).toList(),
        )
      ],
    );
  }
}
